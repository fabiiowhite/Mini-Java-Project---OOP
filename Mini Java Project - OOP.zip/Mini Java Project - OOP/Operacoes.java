package Ex5;

import java.util.Vector;

public interface Operacoes {

    public abstract void addProd(Vector v, Fruta...frutas);

    public abstract void listar(Vector v);

    public abstract void vendaDeDinheiro(Fruta fruta, int quantidade);

    public abstract void buscaEstoque(Vector v, String nomeProduto);
}
