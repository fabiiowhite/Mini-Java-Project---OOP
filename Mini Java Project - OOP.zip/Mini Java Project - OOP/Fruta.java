package Ex5;

public class Fruta {
    private String nomeFruta;
    private double gramas;
    private int quantidade;
    private double preco;
    private boolean frutaEstaMadura;

    public Fruta(String nomeFruta, double gramas, int quantidade, double preco, boolean frutaEstaMadura) {
        this.nomeFruta = nomeFruta;
        this.gramas = gramas;
        this.quantidade = quantidade;
        this.preco = preco;
        this.frutaEstaMadura = frutaEstaMadura;
    }

    public String getNomeFruta() {
        return nomeFruta;
    }

    public void setNomeFruta(String nomeFruta) {
        this.nomeFruta = nomeFruta;
    }

    public double getGramas() {
        return gramas;
    }

    public void setGramas(float gramas) {
        this.gramas = gramas;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public boolean isFrutaEstaMadura() {
        return frutaEstaMadura;
    }

    public void setFrutaEstaMadura(boolean frutaEstaMadura) {
        this.frutaEstaMadura = frutaEstaMadura;
    }

    @Override
    public String toString() {
        return "Fruta{" +
                "nomeFruta='" + nomeFruta + '\'' +
                ", gramas=" + gramas +
                ", quantidade=" + quantidade +
                ", preco=" + preco +
                ", frutaEstaMadura=" + frutaEstaMadura +
                '}';
    }
}
