package Ex5;

import java.util.List;
import java.util.Vector;

public class OperacoesImplementacao implements Operacoes{
    @Override
    public void addProd(Vector v, Fruta... frutas) {
        v.addAll(List.of(frutas));
    }

    @Override
    public void listar(Vector v) {
        for(int i = 0; i < v.size(); i++) {
            if( (((Fruta) v.get(i)).isFrutaEstaMadura())) {
                System.out.println(v.get(i));
            }
        }
    }

    @Override
    public void vendaDeDinheiro(Fruta fruta, int quantidade) {

        if(fruta.isFrutaEstaMadura()) {
            fruta.setQuantidade(fruta.getQuantidade() - quantidade);
            System.out.println("Fruta: "+fruta.getNomeFruta());
            System.out.println("Peso: "+fruta.getGramas());
            System.out.println("Quantidade: "+quantidade);
            System.out.println("Preco/Un: "+fruta.getPreco());
            System.out.println("Total com IVA: "+((fruta.getPreco() + (fruta.getPreco() * 0.17)) * quantidade));
        }else {
            System.out.println("fruta nao madura");
        }


    }

    @Override
    public void buscaEstoque(Vector v, String nomeProduto) {
        for(int i=0;i<v.size();i++) {
            if( (((Fruta) v.get(i)).getNomeFruta()).equals(nomeProduto)) {
                System.out.println(nomeProduto+": "+((Fruta) v.get(i)).getQuantidade());
            }
        }
    }
}
