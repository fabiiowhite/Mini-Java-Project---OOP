package Ex5;

import java.util.Vector;

public class Run {
    public static void main(String[] args) {
        OperacoesImplementacao operacoes = new OperacoesImplementacao();

        Vector<Fruta> feira = new Vector<>();

        Fruta fruta1 = new Fruta("Banana", 200, 200, 20, true);
        Fruta fruta2 = new Fruta("Laranja", 200, 200, 15, true);
        Fruta fruta3 = new Fruta("Maca", 200, 200, 30, false);
        Fruta fruta4 = new Fruta("manga", 200, 200, 10, false);

        operacoes.addProd(feira, fruta1, fruta2, fruta3, fruta4);

        operacoes.listar(feira);

        operacoes.vendaDeDinheiro(fruta3, 10);

        operacoes.buscaEstoque(feira, "Laranja");

    }
}
